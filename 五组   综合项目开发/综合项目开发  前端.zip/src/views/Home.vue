<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <el-row>
    <!-- 左侧上半部分 -->
    <el-col :span="8" style="padding-right :10px">
      <el-card class="box-card">
        <div class="user">
          <img src="../assets/user.jpg" alt=""> 
          <div class="userinfo">
            <p class="name">Admin</p>
            <p class="access">超级管理员</p>
        </div>
      </div>
      <div class="login-info">
        <p>上次登录的时间 ：<span>2022-12-4</span></p>
        <p>上次登录的地点 ：<span>云南工商学院</span></p>
      </div>
      </el-card>
      <!-- 左侧下半部分 -->
      <el-card style="margin-top:20px;padding-right :10px;height: 460px;">
        <el-table
          :data="tableData"
          style="width: 100%">
          <el-table-column v-for="(val,name) in tableLabel" :prop="name" :label="val" />
        </el-table>
      </el-card>
      <div class="grid-content bg-purple"></div>
    </el-col>
    <!-- 右侧部分 -->
    <el-col :span="16">
      <!-- 右侧上半部分 -->
      <div class="num">
        <el-card 
        v-for="item in countData" 
        :key="item.name" 
        :body-style="{ display: 'flex', padding:0}">
          <i class="icon" 
          :class="`el-icon-${item.icon}`"
          :style="{ background:item.color }"
          ></i>
          <div class="detail">
            <p class="price">${{ item.value }}</p>
            <p class="desc">{{ item.name }}</p>
          </div>
        </el-card>
      </div>
      <!-- 右下半部分 -->
      <el-card style="height:280px">
        <!-- 折线图 -->
        <div ref="echarts1" style="height:280px"></div>
      </el-card>
    
    <!-- 柱状图 -->
    </el-col>
</el-row>
</template>

<script>
import { getData } from '../api'
// eslint-disable-next-line no-unused-vars
import * as echarts from 'echarts'

export default {
  data(){
    return{
      tableData:[
   
       ],
      tableLabel:{
        name:'姓名',
        monthBuy:'班级',
        totalBuy:'上课人数',
      },
      countData:[
      {
          name: "今日上课人数",
          value: 2134,
          icon: "success",
          color: "#2ec7c9",
        },
        {
          name: "今日请假人数",
          value: 20,
          icon: "star-on",
          color: "#ffb980",
        },
        {
          name: "今日缺勤人数",
          value: 14,
          icon: "s-goods",
          color: "#5ab1ef",
        },
        {
          name: "老师上课数",
          value: 134,
          icon: "success",
          color: "#2ec7c9",
        },
        {
          name: "老师请假数",
          value: 8,
          icon: "star-on",
          color: "#ffb980",
        },
        {
          name: "老师缺勤数",
          value: 2,
          icon: "s-goods",
          color: "#5ab1ef",
        },
        
      ],
    }
  },
  mounted(){
    getData().then(({data})=>{
     // eslint-disable-next-line no-unused-vars
     const {tableData}  = data.data
     console.log( data.data)
     this.tableData = tableData

      //基于准备好的dom,初始化echarts实例
     const echarts1 =  echarts.init(this.$refs.echarts1)
     //只当图表的配置项和数据
     var echarts1option  = {}

     //处理数据xAxis
     const { orderData,userData,videoData } = data.data
     const xAxis =  Object.keys( orderData.data[0])
     const xAxisData = {
      data:xAxis
     }
     echarts1option.xAxis = xAxisData
     echarts1option.yAxis = {}
     echarts1option.legend = {
      data:xAxis,
     }
     echarts1option.series = []
     xAxis.forEach(key => {
      echarts1option.series.push({
          name:key,
          data:orderData.data.map(item => item[key]),
          type:'line'
      })
     })
     console.log(echarts1option)
       // 使用刚指定的配置项和数据显示图表。
     echarts1.setOption(echarts1option)

      //柱状图
      const echarts2 = echarts.init(this.$refs.echarts2)
      const eacharts2option = {
              legend: {
                // 图例文字颜色
                textStyle: {
                  color: "#333",
                },
              },
              grid: {
                left: "20%",
              },
              // 提示框
              tooltip: {
                trigger: "axis",
              },
              xAxis: {
                type: "category", // 类目轴
                data:userData.map(item => item.date),
                axisLine: {
                  lineStyle: {
                    color: "#17b3a3",
                  },
                },
                axisLabel: {
                  interval: 0,
                  color: "#333",
                }
              },
              yAxis: [
                {
                  type: "value",
                  axisLine: {
                    lineStyle: {
                      color: "#17b3a3",
                    },
                  },
                },
              ],
              color: ["#2ec7c9", "#b6a2de"],
              series: [
                {
                  name:'新增用户',
                  data:userData.map(item => item.new),
                  type:'bar'

                },
                {
                  name:'活跃用户',
                  data:userData.map(item => item.active)
                }
              ],
          }
          echarts2.setOption(eacharts2option)
          //饼状图
          const echarts3 = echarts.init(this.$refs.echarts3)
          const eacharts3option = {
                          tooltip: {
                          trigger: "item",
                        },
                        color: [
                          "#0f78f4",
                          "#dd536b",
                          "#9462e5",
                          "#a6a6a6",
                          "#e1bb22",
                          "#39c362",
                          "#3ed1cf",
                        ],
                        series: [
                          {
                            data:videoData,
                            type:'pie'
                          }
                        ],
          }
          echarts3.setOption(eacharts3option)

      })
    } 

  }
 
</script>

<style lang="less" scoped>
.user{
      padding-bottom: 20px;
      margin-bottom: 20px;
      border-bottom: 1px solid #ccc;
      display: flex;
      align-items: center;

      img{
        margin-right: 45px;
        width: 150px;
        height: 150px;
        border-radius: 50%;
      }
     
    } 
.userinfo{
      .name{
        font-size: 32px;
        margin-bottom: 10px;
        color: burlywood;
              }
      .access{
        color: antiquewhite;
      }
     
    } 
.login-info{
    p{ 
        font-size: 14px;
        line-height: 30px;
        color: #9999;
        span{
            color: #666;
            margin-left: 60px;
        }
      }
}
// 左上半部分
.num{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  .icon{
    width: 80px;
    height: 80px;
    font-size: 30px;
    color: #ccc;
    text-align: center;
    line-height: 80px;
  }
  .detail{
      display: flex;
      flex-direction: column;
      justify-content: center;
      margin-left: 15px;

      .price{
        font-size: 30px;
        margin-bottom: 10px;
        line-height: 30px;
        height: 30px;

    }
    .desc{
        font-size: 14px;
        color: #999;
        text-align:center;
        }
    }
    .el-card{
      width: 32%;
      margin-bottom: 20px;
      
    }
    
}

.graph{
  display: flex;
  justify-content: space-between;
  .el-card{
    width: 48%;
    margin-top: 20px;
  }
}

      

</style>