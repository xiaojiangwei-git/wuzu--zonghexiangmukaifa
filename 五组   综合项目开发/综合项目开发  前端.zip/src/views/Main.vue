<!-- eslint-disable vue/multi-word-component-names -->
<template>
    <div>
      <el-container>
        <el-aside width="auto">
            <common-aside/>
        </el-aside>
        <el-container>
            <el-header>
                <Common-header/>
            </el-header>

            <common-tag/>
            <el-main>
                <!-- 路由出口 -->
                <!-- 路由匹配到的组件将渲染在这里 -->
                <router-view></router-view>
            </el-main>
        </el-container>
      </el-container>
    </div>
</template>

<script>

import CommonAside from '../components/CommonAside.vue'
import CommonHeader from '../components/CommonHeader.vue';
import CommonTag from '../components/CommonTag.vue';

export default {
    data() {
        return {};
    },
    components: {
        CommonAside,
        CommonHeader,
        CommonTag,
        // eslint-disable-next-line no-dupe-keys
        CommonTag
    }

}

</script>

<style>
    .el-header{
        padding: 0;
    }
    .el-menu{
        border-right: none;
    }
</style>