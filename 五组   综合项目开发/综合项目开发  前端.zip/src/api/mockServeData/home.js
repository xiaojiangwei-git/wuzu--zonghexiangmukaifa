// mock数据模拟
import Mock from 'mockjs'

// 图表数据
let List = []
export default {
  getStatisticalData: () => {
    //Mock.Random.float 产生随机数100到8000之间 保留小数 最小0位 最大0位
    for (let i = 0; i < 7; i++) {
      List.push(
        Mock.mock({
          张三: Mock.Random.float(100, 800, 0, 0),
          王五: Mock.Random.float(100, 800, 0, 0),
          李强: Mock.Random.float(100, 800, 0, 0),
          保罗: Mock.Random.float(100, 800, 0, 0),
          王红: Mock.Random.float(100, 800, 0, 0),
          李四: Mock.Random.float(100, 800, 0, 0),
          张达: Mock.Random.float(100, 800, 0, 0)
        })
      )
    }
    return {
      code: 200,
      data: {
         // 折线图
         orderData: {
          date: ['345', '1243', '534', '213', '131', '343', '545'],
          data: List
        },
        tableData: [
          {
            name: '李强',
            monthBuy: "软件技术3班",
            totalBuy: 45
          },
          {
            name: '王五',
            monthBuy: "软件技术1班",
            totalBuy: 65
          },
          {
            name: '张三',
            monthBuy: "软件技术2班",
            totalBuy: 31
          },
          {
            name: '李四',
            monthBuy: "软件技术1班",
            totalBuy: 64
          },
          {
            name: '王红',
            monthBuy: "软件技术2班",
            totalBuy: 54
          },
          {
            name: '保罗',
            monthBuy: "软件技术3班",
            totalBuy: 32
          },
          {
            name: '张达',
            monthBuy: "软件技术2班",
            totalBuy: 76
          },
         
        ]
      }
    }
  }
}
